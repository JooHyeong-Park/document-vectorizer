# Azure DevOps Server deployment package

This directory is self-contained and is the only directory that needs to be imported into the on-prem Azure DevOps Server repository.

## Structure

```text
azure-devops/
├── azure-pipelines.yml
├── _common.sh
├── _auth.sh
├── deploy-app.sh
├── get-log.sh
└── templates/
    ├── deploy-app.yml
    └── get-log.yml
```

- `azure-pipelines.yml`: environment values and template composition.
- `templates/deploy-app.yml`: deployment step.
- `templates/get-log.yml`: diagnostic log step, executed even if deployment fails.
- `templates/_common.sh`: ARM REST helpers.
- `templates/_auth.sh`: authentication boundary.
- `templates/deploy-app.sh`: App Service image deployment.
- `templates/get-log.sh`: App Service container log retrieval.

## Temporary Azure access token

All code that exists only for the pre-Service-Principal access-token flow is marked with:

```text
# START TEMPORARY AZURE ACCESS TOKEN
...
# END TEMPORARY AZURE ACCESS TOKEN
```

After the Service Principal is created, those blocks are the intended deletion/modification points.

`AZURE_TENANT_ID` and `AZURE_CLIENT_ID` can remain in `azure-pipelines.yml`. Only `AZURE_CLIENT_SECRET` should be stored as a secret Azure DevOps variable.

## Agent requirements

- Bash
- curl
- standard Unix utilities (`sed`, `tr`, `mktemp`)

Azure CLI, jq and Python are not required by the deployment scripts.
