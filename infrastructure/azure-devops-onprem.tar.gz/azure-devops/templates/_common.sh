#!/usr/bin/env bash

# Shared helpers for the on-prem Azure DevOps deployment scripts.
# No Azure CLI, jq, or Python dependency is required.

set -Eeuo pipefail

: "${ARM_ENDPOINT:=https://management.azure.com}"
: "${APP_SERVICE_API_VERSION:=2025-05-01}"

log() {
    printf '[%s] %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$*"
}

warn() {
    printf '[%s] WARN: %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$*" >&2
}

die() {
    printf '[%s] ERROR: %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$*" >&2
    exit 1
}

require_command() {
    command -v "$1" >/dev/null 2>&1 || die "Required command not found: $1"
}

require_env() {
    local name="$1"
    [[ -n "${!name:-}" ]] || die "Required environment variable is empty: ${name}"
}

# Percent-encode one URL path segment without external tools.
urlencode_segment() {
    local LC_ALL=C
    local value="$1"
    local encoded=""
    local c
    local i

    for ((i = 0; i < ${#value}; i++)); do
        c="${value:i:1}"
        case "$c" in
            [a-zA-Z0-9.~_-]) encoded+="$c" ;;
            *) printf -v c '%%%02X' "'$c"; encoded+="$c" ;;
        esac
    done

    printf '%s' "$encoded"
}

webapp_resource_path() {
    require_env AZURE_SUBSCRIPTION_ID
    require_env AZURE_RESOURCE_GROUP
    require_env AZURE_WEBAPP_NAME

    printf '/subscriptions/%s/resourceGroups/%s/providers/Microsoft.Web/sites/%s' \
        "${AZURE_SUBSCRIPTION_ID}" \
        "$(urlencode_segment "${AZURE_RESOURCE_GROUP}")" \
        "$(urlencode_segment "${AZURE_WEBAPP_NAME}")"
}

# Usage:
#   arm_request GET  "/subscriptions/...?..."
#   arm_request PATCH "/subscriptions/...?..." '{"properties":{...}}'
#
# The response body is written to stdout. Any non-2xx response fails the script.
arm_request() {
    local method="$1"
    local path="$2"
    local body="${3:-}"
    local url="${ARM_ENDPOINT}${path}"
    local response_file
    local http_code

    require_command curl
    require_env AZURE_ACCESS_TOKEN

    response_file="$(mktemp "${TMPDIR:-/tmp}/azure-arm-response.XXXXXX")"

    # Never enable shell xtrace around this function: the bearer token must not
    # be printed in the Azure DevOps job log.
    set +x

    if [[ -n "$body" ]]; then
        http_code="$(curl \
            --silent \
            --show-error \
            --connect-timeout 20 \
            --max-time 180 \
            --output "$response_file" \
            --write-out '%{http_code}' \
            --request "$method" \
            --header "Authorization: Bearer ${AZURE_ACCESS_TOKEN}" \
            --header 'Content-Type: application/json' \
            --data "$body" \
            "$url")" || {
                local rc=$?
                rm -f "$response_file"
                die "ARM request failed before receiving an HTTP response (curl rc=${rc}): ${method} ${path}"
            }
    else
        http_code="$(curl \
            --silent \
            --show-error \
            --connect-timeout 20 \
            --max-time 180 \
            --output "$response_file" \
            --write-out '%{http_code}' \
            --request "$method" \
            --header "Authorization: Bearer ${AZURE_ACCESS_TOKEN}" \
            "$url")" || {
                local rc=$?
                rm -f "$response_file"
                die "ARM request failed before receiving an HTTP response (curl rc=${rc}): ${method} ${path}"
            }
    fi

    case "$http_code" in
        2??)
            cat "$response_file"
            rm -f "$response_file"
            ;;
        *)
            printf 'ARM request failed: HTTP %s %s %s\n' "$http_code" "$method" "$path" >&2
            cat "$response_file" >&2
            printf '\n' >&2
            rm -f "$response_file"
            return 1
            ;;
    esac
}
