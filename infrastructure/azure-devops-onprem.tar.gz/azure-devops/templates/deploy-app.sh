#!/usr/bin/env bash

# Deploy a new image to an existing Linux App Service custom-container app.
# Existing ACR authentication / Managed Identity settings are left unchanged.

set -Eeuo pipefail
set +x

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=_common.sh
source "${SCRIPT_DIR}/_common.sh"
# shellcheck source=_auth.sh
source "${SCRIPT_DIR}/_auth.sh"

image_tag=""
temporary_azure_access_token=""

usage() {
    cat <<'USAGE'
Usage:
  ./deploy-app.sh --image-tag <tag> --azure-access-token <token>

Arguments:
  --image-tag            Container image tag to deploy.
  --azure-access-token   Temporary Azure Resource Manager access token.
USAGE
}

while [[ $# -gt 0 ]]; do
    case "$1" in
        --image-tag)
            [[ $# -ge 2 ]] || die "Missing value for --image-tag"
            image_tag="$2"
            shift 2
            ;;
        # START TEMPORARY AZURE ACCESS TOKEN
        # Delete this argument after Service Principal authentication is enabled.
        --azure-access-token)
            [[ $# -ge 2 ]] || die "Missing value for --azure-access-token"
            temporary_azure_access_token="$2"
            shift 2
            ;;
        # END TEMPORARY AZURE ACCESS TOKEN
        -h|--help)
            usage
            exit 0
            ;;
        *)
            die "Unknown argument: $1"
            ;;
    esac
done

require_env ACR_LOGIN_SERVER
require_env IMAGE_REPOSITORY
[[ -n "$image_tag" ]] || die "--image-tag is required."

if [[ ! "$image_tag" =~ ^[A-Za-z0-9_][A-Za-z0-9_.-]{0,127}$ ]]; then
    die "Invalid Docker image tag: ${image_tag}"
fi

DEPLOY_IMAGE="${ACR_LOGIN_SERVER}/${IMAGE_REPOSITORY}:${image_tag}"
export DEPLOY_IMAGE

# START TEMPORARY AZURE ACCESS TOKEN
# Replace this call with init_azure_auth after the temporary token path is removed.
init_azure_auth "$temporary_azure_access_token"
# END TEMPORARY AZURE ACCESS TOKEN

validate_arm_token

if [[ ! "${DEPLOY_IMAGE}" =~ ^[A-Za-z0-9._:/@-]+$ ]]; then
    die "DEPLOY_IMAGE contains unsupported characters: ${DEPLOY_IMAGE}"
fi

resource_path="$(webapp_resource_path)"
config_path="${resource_path}/config/web?api-version=${APP_SERVICE_API_VERSION}"
restart_path="${resource_path}/restart?api-version=${APP_SERVICE_API_VERSION}&synchronous=true"

log "Target App Service : ${AZURE_WEBAPP_NAME}"
log "Resource Group     : ${AZURE_RESOURCE_GROUP}"
log "Container Image    : ${DEPLOY_IMAGE}"
log "Updating App Service container image through ARM REST API..."

payload="{\"properties\":{\"linuxFxVersion\":\"DOCKER|${DEPLOY_IMAGE}\"}}"
arm_request PATCH "$config_path" "$payload" >/dev/null

log "Restarting App Service..."
arm_request POST "$restart_path" >/dev/null

log "Deployment request completed successfully."
