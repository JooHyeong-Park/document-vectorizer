#!/usr/bin/env bash

# Print the latest App Service container logs using Azure ARM REST API.

set -Eeuo pipefail
set +x

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=_common.sh
source "${SCRIPT_DIR}/_common.sh"
# shellcheck source=_auth.sh
source "${SCRIPT_DIR}/_auth.sh"

temporary_azure_access_token=""

while [[ $# -gt 0 ]]; do
    case "$1" in
        # START TEMPORARY AZURE ACCESS TOKEN
        # Delete this argument after Service Principal authentication is enabled.
        --azure-access-token)
            [[ $# -ge 2 ]] || die "Missing value for --azure-access-token"
            temporary_azure_access_token="$2"
            shift 2
            ;;
        # END TEMPORARY AZURE ACCESS TOKEN
        -h|--help)
            printf 'Usage: ./get-log.sh --azure-access-token <token>\n'
            exit 0
            ;;
        *)
            die "Unknown argument: $1"
            ;;
    esac
done

# START TEMPORARY AZURE ACCESS TOKEN
# Replace this call with init_azure_auth after the temporary token path is removed.
init_azure_auth "$temporary_azure_access_token"
# END TEMPORARY AZURE ACCESS TOKEN

validate_arm_token

resource_path="$(webapp_resource_path)"
logs_path="${resource_path}/containerlogs?api-version=${APP_SERVICE_API_VERSION}"

log "Fetching latest container logs for ${AZURE_WEBAPP_NAME}..."
printf '%s\n' '-------------------- container logs --------------------'
arm_request POST "$logs_path"
printf '\n%s\n' '--------------------------------------------------------'
