#!/usr/bin/env bash

# Azure authentication boundary shared by deploy-app.sh and get-log.sh.
# Azure CLI is not required.

set -Eeuo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=_common.sh
source "${SCRIPT_DIR}/_common.sh"

# Service Principal authentication kept as the final target implementation.
# AZURE_TENANT_ID and AZURE_CLIENT_ID may be hardcoded in the main pipeline.
# Only AZURE_CLIENT_SECRET should be supplied as an Azure DevOps secret variable.
acquire_service_principal_token() {
    require_env AZURE_TENANT_ID
    require_env AZURE_CLIENT_ID
    require_env AZURE_CLIENT_SECRET
    require_command curl
    require_command sed
    require_command tr

    local token_url
    local response
    local token

    token_url="https://login.microsoftonline.com/${AZURE_TENANT_ID}/oauth2/v2.0/token"

    set +x
    response="$(curl \
        --silent \
        --show-error \
        --fail \
        --connect-timeout 20 \
        --max-time 60 \
        --request POST \
        --header 'Content-Type: application/x-www-form-urlencoded' \
        --data-urlencode "client_id=${AZURE_CLIENT_ID}" \
        --data-urlencode "client_secret=${AZURE_CLIENT_SECRET}" \
        --data-urlencode 'scope=https://management.azure.com/.default' \
        --data-urlencode 'grant_type=client_credentials' \
        "$token_url")" || die "Failed to acquire an Azure Resource Manager access token using the Service Principal."

    token="$(printf '%s' "$response" | tr -d '\r\n' | sed -n 's/.*"access_token"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p')"
    [[ -n "$token" ]] || die "Token endpoint response did not contain access_token."

    AZURE_ACCESS_TOKEN="$token"
    export AZURE_ACCESS_TOKEN
}

init_azure_auth() {
    local temporary_token="${1:-}"

    # START TEMPORARY AZURE ACCESS TOKEN
    # Delete this block after Service Principal authentication is enabled.
    # Until then, the ARM access token is supplied directly as a pipeline
    # runtime parameter and passed to deploy-app.sh/get-log.sh.
    if [[ -n "$temporary_token" && "$temporary_token" != '__REQUIRED__' ]]; then
        AZURE_ACCESS_TOKEN="$temporary_token"
        export AZURE_ACCESS_TOKEN
        return 0
    fi
    # END TEMPORARY AZURE ACCESS TOKEN

    # Final authentication path after the temporary block is removed.
    if [[ -n "${AZURE_CLIENT_SECRET:-}" ]]; then
        acquire_service_principal_token
        return 0
    fi

    die "Azure authentication is not configured."
}

validate_arm_token() {
    local resource_path
    resource_path="$(webapp_resource_path)"
    arm_request GET "${resource_path}?api-version=${APP_SERVICE_API_VERSION}" >/dev/null
}
